-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: new_test
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `name_trans` varchar(100) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `small_text` varchar(30) DEFAULT NULL,
  `big_text` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Name new_1','Name new',33.23,'smal text 5','new_value 1',123),(2,'Тавар № 2','product_2',200,'test small text 2','test big text 2',3),(3,'Тавар № 3','product_3',31.23,'test small text 3','test big text 3',4),(5,'name_5','Product_5',333,'tex 5assdafafsfdfsdfdsf1223232','<big>tex<t> 5assdafafsfdfsdfdsf1223232414421',123),(6,'Name_6','Product_6',222,'smal text 6','big text 6',23),(7,'Name_7','Product_7',111,'smal text 7','big text 7',33),(8,'Name_85','Product_8',2311,'smal text 8','big text 8',221),(9,'Name_8','Product_8',2311,'smal text 8','big text 8',221),(10,'Name_85','Product_8',2311,' te 8123213213dsfdsfsd3432dsfs','<big> te<xt> 8123213213dsfdsfsd3432dsfsfwww2231241',221),(22,'Name_99','Product_9229',22,'smal text 22','big text 22',21),(55,'name_5','Product_5',333,'tex 5assdafafsfdfsdfdsf1223232','<big>tex<t> 5assdafafsfdfsdfdsf1223232414421',5),(56,'name_5','Product_5',333,'tex 5assdafafsfdfsdfdsf1223232','<big>tex<t> 5assdafafsfdfsdfdsf1223232414421',123),(75,'Name_75','Product_75',75,'smal text 75','big text 75',123),(76,'Name_2','Product_76',75,'smal text 76','big text 76',123),(77,'Name_77','Product_77',75,'smal text 77','big text 77',123),(79,'Name_79','Product_79',79,'smal text 79','big text 79',123),(80,'Name_80','Product_80',80,'smal text 80','big text 79',332);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-15 16:48:35
